# TeamTalk Music Bot (Android starter)

This is a starter Android Studio project for a TeamTalk music bot.

## What is included
- Android app shell and connection settings UI
- Add/remove tracks in a queue
- Save and load named playlists locally
- Basic play / pause / skip controls (UI hooks)
- A clearly separated `TeamTalkGateway` adapter where the official TeamTalk SDK is integrated

## Important: SDK integration is still required
This starter intentionally does **not** bundle TeamTalk's proprietary/native SDK files.
Download the official TeamTalk 5 Android SDK from BearWare and review its license:
https://bearware.dk/?page_id=419

The official Android sample and SDK structure are documented in:
https://github.com/BearWare/TeamTalk5

Add the SDK files following the vendor's current instructions. The older sample layout uses:
- `TeamTalk5.jar` in `app/libs/`
- Android JNI libraries under `app/src/main/jniLibs/<abi>/`

Then implement the methods in `TeamTalkGateway.java` using the exact Java API in the SDK version you downloaded. API names can differ by SDK release.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

The app shell can be built before SDK integration, but it will not connect to TeamTalk or stream audio until the gateway is implemented and the SDK files are added.

## YouTube note
The starter accepts a track title and a media URL as queue metadata. It does not extract audio from YouTube. For actual playback, use media you own/have permission to stream, or a source and method permitted by the provider's terms. TeamTalk's media-file streaming API streams supported local media files to a channel.

## Permissions / background operation
This starter includes Internet access only. A production bot should use a foreground service with a persistent notification while connected/streaming, and should handle Android battery/background restrictions.


## Build from an Android phone (cloud build)
This project includes `.github/workflows/android-build.yml`.

1. On your phone, sign in to GitHub and create a new repository.
2. Upload the contents of this project ZIP to the repository (keep the `.github/workflows/android-build.yml` path).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Tap **Run workflow** (or wait for the build triggered by pushing to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `TeamTalkMusicBot-debug-apk`.
6. Extract the downloaded artifact ZIP and install the APK. Android may ask you to allow installs from your browser or file manager.

This cloud workflow builds the current app shell only. It does not add the TeamTalk SDK or make the bot connect/stream yet. The SDK integration must be completed before the app functions as a real TeamTalk music bot.
