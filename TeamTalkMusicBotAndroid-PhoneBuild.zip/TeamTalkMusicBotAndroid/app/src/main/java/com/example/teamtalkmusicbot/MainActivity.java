package com.example.teamtalkmusicbot;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private EditText host, tcpPort, udpPort, username, password, nickname;
    private EditText trackTitle, mediaUri;
    private TextView status, nowPlaying;
    private ListView queueView;
    private ArrayAdapter<Track> adapter;
    private final ArrayList<Track> queue = new ArrayList<>();
    private PlaylistStore playlists;
    private TeamTalkGateway gateway;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        playlists = new PlaylistStore(this);
        gateway = new TeamTalkGateway();
        buildUi();
        gateway.setListener(message -> runOnUiThread(() -> status.setText(message)));
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setPadding(28, 24, 28, 24);
        page.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(page);

        TextView heading = new TextView(this);
        heading.setText("TeamTalk Music Bot");
        heading.setTextSize(25);
        heading.setGravity(Gravity.CENTER);
        page.addView(heading);

        page.addView(section("TeamTalk connection"));
        host = field("Server address");
        tcpPort = field("TCP port (default 10333)");
        tcpPort.setText("10333");
        udpPort = field("UDP port (default 10333)");
        udpPort.setText("10333");
        username = field("Username");
        password = field("Password");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        nickname = field("Bot nickname");
        nickname.setText("MusicBot");

        Button connect = button("Connect (SDK setup required)");
        connect.setOnClickListener(v -> {
            try {
                gateway.connect(host.getText().toString(), Integer.parseInt(tcpPort.getText().toString()),
                    Integer.parseInt(udpPort.getText().toString()), username.getText().toString(),
                    password.getText().toString(), nickname.getText().toString());
            } catch (Exception e) { status.setText("Check the server ports."); }
        });
        page.addView(connect);

        page.addView(section("Add a track"));
        trackTitle = field("Song title");
        mediaUri = field("Media URL or local file path");
        Button add = button("Add to queue");
        add.setOnClickListener(v -> addTrack());
        page.addView(add);

        page.addView(section("Queue"));
        nowPlaying = new TextView(this);
        nowPlaying.setText("Now playing: nothing");
        page.addView(nowPlaying);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, queue);
        queueView = new ListView(this);
        queueView.setAdapter(adapter);
        queueView.setOnItemLongClickListener((parent, view, position, id) -> {
            queue.remove(position); adapter.notifyDataSetChanged(); return true;
        });
        page.addView(queueView, new LinearLayout.LayoutParams(-1, 300));

        LinearLayout controls = new LinearLayout(this);
        controls.addView(button("Play", v -> playNext()));
        controls.addView(button("Pause", v -> gateway.pause()));
        controls.addView(button("Skip", v -> playNext()));
        controls.addView(button("Stop", v -> { gateway.stop(); nowPlaying.setText("Now playing: nothing"); }));
        page.addView(controls);

        page.addView(section("Playlists"));
        Button save = button("Save current queue");
        save.setOnClickListener(v -> askPlaylistName(true));
        page.addView(save);
        Button load = button("Load playlist");
        load.setOnClickListener(v -> showPlaylists());
        page.addView(load);

        page.addView(section("Status"));
        status = new TextView(this);
        status.setText("Ready. Add the official TeamTalk SDK to enable server connection and streaming.");
        page.addView(status);

        TextView hint = new TextView(this);
        hint.setText("\nTip: long-press a queue item to remove it. This starter stores playlists on this phone.");
        page.addView(hint);
        setContentView(scroll);
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText("\n" + text);
        view.setTextSize(18);
        view.setPadding(0, 14, 0, 6);
        return view;
    }

    private EditText field(String hint) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint(hint);
        // Add to the current page container.
        ((LinearLayout)((ScrollView)findViewById(android.R.id.content).getChildAt(0)).getChildAt(0)).addView(edit);
        return edit;
    }

    private Button button(String label) {
        return button(label, null);
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        if (listener != null) b.setOnClickListener(listener);
        return b;
    }

    private void addTrack() {
        String title = trackTitle.getText().toString().trim();
        String uri = mediaUri.getText().toString().trim();
        if (uri.isEmpty()) { status.setText("Enter a media URL or local file path."); return; }
        queue.add(new Track(title.isEmpty() ? uri : title, uri));
        adapter.notifyDataSetChanged();
        trackTitle.setText(""); mediaUri.setText("");
    }

    private void playNext() {
        if (queue.isEmpty()) { status.setText("The queue is empty."); return; }
        Track track = queue.get(0);
        nowPlaying.setText("Now playing: " + track.title);
        gateway.playMediaFile(track.mediaUri);
    }

    private void askPlaylistName(boolean save) {
        EditText input = new EditText(this);
        input.setHint("Playlist name");
        new AlertDialog.Builder(this).setTitle("Save playlist").setView(input)
            .setPositiveButton("Save", (d, w) -> {
                String name = input.getText().toString().trim();
                if (!name.isEmpty()) { playlists.save(name, queue); status.setText("Saved playlist: " + name); }
            }).setNegativeButton("Cancel", null).show();
    }

    private void showPlaylists() {
        String[] names = playlists.names();
        if (names.length == 0) { status.setText("No saved playlists yet."); return; }
        new AlertDialog.Builder(this).setTitle("Choose playlist").setItems(names, (d, which) -> {
            queue.clear(); queue.addAll(playlists.load(names[which])); adapter.notifyDataSetChanged();
            status.setText("Loaded playlist: " + names[which]);
        }).show();
    }
}
