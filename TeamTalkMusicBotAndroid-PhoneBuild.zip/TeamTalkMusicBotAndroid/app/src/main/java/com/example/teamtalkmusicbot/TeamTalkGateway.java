package com.example.teamtalkmusicbot;

/**
 * Integration boundary for the official TeamTalk 5 Android SDK.
 *
 * Replace the placeholder bodies with calls to the SDK version you install.
 * Consult the SDK's Java API docs and TeamTalkAndroid sample; do not guess
 * method signatures across SDK versions.
 */
public class TeamTalkGateway {
    public interface Listener {
        void onStatus(String message);
    }

    private Listener listener;

    public void setListener(Listener listener) { this.listener = listener; }

    public void connect(String host, int tcpPort, int udpPort,
                        String username, String password, String nickname) {
        notifyStatus("SDK not connected yet. Add TeamTalk SDK and implement this adapter.");
        // TODO: initialize TeamTalk instance, connect, log in, and join requested channel.
    }

    public void playMediaFile(String localFilePath) {
        notifyStatus("Playback adapter not implemented. Requires TeamTalk SDK.");
        // TODO: stream supported media file to the joined channel.
        // C API equivalent: TT_StartStreamingMediaFileToChannel(...)
    }

    public void pause() {
        notifyStatus("Pause adapter not implemented.");
        // TODO: update active media-file playback state.
    }

    public void stop() {
        notifyStatus("Stop adapter not implemented.");
        // TODO: stop media streaming and clean up playback state.
    }

    public void disconnect() {
        notifyStatus("Disconnect adapter not implemented.");
        // TODO: leave channel, log out, disconnect, and release SDK instance.
    }

    private void notifyStatus(String message) {
        if (listener != null) listener.onStatus(message);
    }
}
