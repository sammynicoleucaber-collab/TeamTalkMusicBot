package com.example.teamtalkmusicbot;

public class Track {
    public final String title;
    public final String mediaUri;

    public Track(String title, String mediaUri) {
        this.title = title == null ? "" : title.trim();
        this.mediaUri = mediaUri == null ? "" : mediaUri.trim();
    }

    @Override public String toString() {
        return title.isEmpty() ? mediaUri : title;
    }
}
