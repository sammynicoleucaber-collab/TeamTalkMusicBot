package com.example.teamtalkmusicbot;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class PlaylistStore {
    private final SharedPreferences prefs;

    public PlaylistStore(Context context) {
        prefs = context.getSharedPreferences("playlists", Context.MODE_PRIVATE);
    }

    public void save(String name, ArrayList<Track> tracks) {
        try {
            JSONArray arr = new JSONArray();
            for (Track t : tracks) {
                JSONObject obj = new JSONObject();
                obj.put("title", t.title);
                obj.put("uri", t.mediaUri);
                arr.put(obj);
            }
            prefs.edit().putString(name, arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    public ArrayList<Track> load(String name) {
        ArrayList<Track> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(name, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                result.add(new Track(obj.optString("title"), obj.optString("uri")));
            }
        } catch (Exception ignored) { }
        return result;
    }

    public String[] names() {
        Map<String, ?> all = prefs.getAll();
        return all.keySet().toArray(new String[0]);
    }
}
